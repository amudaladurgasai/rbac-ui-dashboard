import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { RBACProvider } from "./context/RBACContext";
import Dashboard from "./pages/Dashboard";
import Users from "./pages/Users";
import Roles from "./pages/Roles";
import Logs from "./pages/Logs";
import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  return (
    <RBACProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route
            path="/users"
            element={
              <ProtectedRoute allowedRoles={["Admin"]}>
                <Users />
              </ProtectedRoute>
            }
          />
          <Route
            path="/roles"
            element={
              <ProtectedRoute allowedRoles={["Admin", "Editor"]}>
                <Roles />
              </ProtectedRoute>
            }
          />
          <Route
            path="/logs"
            element={
              <ProtectedRoute allowedRoles={["Admin"]}>
                <Logs />
              </ProtectedRoute>
            }
          />
        </Routes>
      </Router>
    </RBACProvider>
  );
}

export default App;

