import React, { createContext, useState, useEffect } from "react";

export const RBACContext = createContext();

export const RBACProvider = ({ children }) => {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    setUsers([{ id: 1, name: "Admin", roles: ["Admin"] }]);
    setRoles([{ id: 1, name: "Admin", permissions: ["manage_users"] }]);
    setPermissions([{ id: "manage_users", description: "Manage Users" }]);
  }, []);

  const addLog = (action, details) => {
    setLogs((prevLogs) => [
      ...prevLogs,
      { id: prevLogs.length + 1, action, details, timestamp: new Date() },
    ]);
  };

  return (
    <RBACContext.Provider value={{ users, roles, permissions, logs, setUsers, setRoles, setPermissions, addLog }}>
      {children}
    </RBACContext.Provider>
  );
};
