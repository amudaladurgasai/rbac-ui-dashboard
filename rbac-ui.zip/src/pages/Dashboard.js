import React from "react";

const Dashboard = () => {
  return <h1>Welcome to the RBAC Dashboard</h1>;
};

export default Dashboard;
