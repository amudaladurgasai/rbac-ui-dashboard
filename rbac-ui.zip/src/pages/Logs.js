import React, { useContext } from "react";
import { RBACContext } from "../context/RBACContext";

const Logs = () => {
  const { logs } = useContext(RBACContext);

  return (
    <div>
      <h1>Audit Logs</h1>
      <ul>
        {logs.map((log) => (
          <li key={log.id}>
            {log.action} - {log.details} - {new Date(log.timestamp).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Logs;
