import React, { useContext } from "react";
import { RBACContext } from "../context/RBACContext";

const Roles = () => {
  const { roles } = useContext(RBACContext);

  return (
    <div>
      <h1>Roles</h1>
      <ul>
        {roles.map((role) => (
          <li key={role.id}>{role.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default Roles;
