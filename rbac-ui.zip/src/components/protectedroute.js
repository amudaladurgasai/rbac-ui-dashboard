import React, { useContext } from "react";
import { Navigate } from "react-router-dom";
import { RBACContext } from "../context/RBACContext";

const ProtectedRoute = ({ allowedRoles, children }) => {
  const { users } = useContext(RBACContext);
  const currentUser = users[0]; // Mock logged-in user
  const userRoles = currentUser.roles;

  const hasAccess = userRoles.some((role) => allowedRoles.includes(role));
  return hasAccess ? children : <Navigate to="/" />;
};

export default ProtectedRoute;
