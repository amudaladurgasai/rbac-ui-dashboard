const express = require("express");
const app = express();
app.use(express.json());

let users = [];
let roles = [];
let logs = [];

app.get("/api/users", (req, res) => res.json(users));

app.post("/api/users", (req, res) => {
  const newUser = req.body;
  users.push(newUser);
  logs.push({ action: "User Added", details: `Added user ${newUser.name}`, timestamp: new Date() });
  res.status(201).json(newUser);
});

app.get("/api/roles", (req, res) => res.json(roles));

app.listen(5000, () => console.log("Server running on http://localhost:5000"));

const cors = require("cors");
app.use(cors());

